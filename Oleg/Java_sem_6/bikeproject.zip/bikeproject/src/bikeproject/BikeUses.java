package bikeproject;

public enum BikeUses {
    off_road,
    track,
    road,
    downhill,
    trail
}
