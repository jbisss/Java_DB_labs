package Cub;

public class  Cuboid <side extends Number>{
    private side width;
    private side height;
    private side length;

    public Cuboid(side width, side height, side length) {
        this.width = width;
        this.height = height;
        this.length = length;
    }

    public double getVolume(){
        return width.doubleValue()*height.doubleValue()*length.doubleValue();
    }

    public String toString(){
        return "This cuboid has :"+
                width+" width, "+
                height+" height, "+
                length+" length.";
    }

    public side getWidth() {
        return width;
    }

    public side getHeight() {
        return height;
    }

    public side getLength() {
        return length;
    }

    public void setWidth(side width) {
        this.width = width;
    }

    public void setHeight(side height) {
        this.height = height;
    }

    public void setLength(side length) {
        this.length = length;
    }

}
