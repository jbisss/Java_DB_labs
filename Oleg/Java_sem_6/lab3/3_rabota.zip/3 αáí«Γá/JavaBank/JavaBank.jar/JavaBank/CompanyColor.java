package JavaBank;

public final class CompanyColor {
    private final int R = 238;
    private final int G = 120;
    private final int B = 238;

    public int getR() {
        return R;
    }

    public int getG() {
        return G;
    }

    public int getB() {
        return B;
    }
}
