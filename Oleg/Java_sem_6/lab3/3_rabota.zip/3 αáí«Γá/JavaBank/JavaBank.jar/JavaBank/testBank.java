package JavaBank;

public class testBank {
	public static void main(String[] args) {
		Account a1 = new Account("Sujjey Gupta", 11556,300);
		Account a2 = new Account("He Xai", 22338,500);
		Account a3=new Account("Ilya Mustafana", 44559,1000);



	}
}
