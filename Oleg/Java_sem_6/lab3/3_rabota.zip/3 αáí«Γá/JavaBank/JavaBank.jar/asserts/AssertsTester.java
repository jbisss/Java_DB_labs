package asserts;


import java.util.Scanner;

public class AssertsTester {
    public static void main(String[] args){
        //First();
        //Second();
        Third();
    }

    public static void First(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите неотрицательное число: ");

        int value = scanner.nextInt();
        scanner.close();

        assert (value>=0):"Надо было неотрицательное.....";
        System.out.println("Отлично!");
    }

    public static void Second(){
        Scanner scanner2 = new Scanner(System.in);
        System.out.print("Выберете 7 или 13 :");
        int value = scanner2.nextInt();

        scanner2.close();

        switch (value){
            case 7:
                System.out.println("Счастливое!");
                break;
            case 13:
                System.out.println("Не повезло!");
                break;
            default:
                assert (false);
                break;
        }
    }

    public static void Third(){
        System.out.print("Введите \"Привет\" :");

        Scanner scanner = new Scanner(System.in);

        String line = scanner.nextLine();
        scanner.close();

        assert (line.equals("\"Привет\"")): "Неверно :(";
        System.out.println("Все верно!");
    }
}
