package com.practice_8;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Planner.startSeason();
    }
}
