//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.practice_8;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class Planner {
    public Planner() {
    }

    public static void startSeason() {
        Team[] teamArray = new Team[]{new Team("Liverpool"), new Team("Real Madrid"), new Team("Barcelona"), new Team("Manchester City")};
        int countColdDays = 0;
        Scanner in = new Scanner(System.in);

        do {
            while(true) {
                int temperature;
                while(true) {
                    System.out.println("Enter the value of temperature:");

                    try {
                        String input = in.nextLine();
                        temperature = Integer.parseInt(input);
                        break;
                    } catch (ClassCastException var10) {
                        var10.printStackTrace();
                    }
                }

                if (temperature < 0) {
                    System.out.println("Too cold to play!!!");
                    ++countColdDays;
                    break;
                }

                Set<Integer> numberSet = new HashSet(Arrays.asList(0, 1, 2, 3));
                countColdDays = 0;
                Random rand_1 = new Random();
                Random rand_2 = new Random();
                int firstTeamNumber = 0;

                int secondTeamNumber;
                for(secondTeamNumber = 0; firstTeamNumber == secondTeamNumber; secondTeamNumber = rand_2.nextInt(4)) {
                    firstTeamNumber = rand_1.nextInt(4);
                }

                numberSet.remove(firstTeamNumber);
                numberSet.remove(secondTeamNumber);
                new Game(teamArray[firstTeamNumber], teamArray[secondTeamNumber], temperature);
                Iterator<Integer> iterator = numberSet.iterator();
                firstTeamNumber = (Integer)iterator.next();
                secondTeamNumber = (Integer)iterator.next();
                new Game(teamArray[firstTeamNumber], teamArray[secondTeamNumber], temperature);
            }
        } while(countColdDays != 3);

        Team[] var11 = teamArray;
        int var13 = teamArray.length;

        for(int var14 = 0; var14 < var13; ++var14) {
            Team team = var11[var14];
            team.printStats();
        }

        Game.printSeasonStats();
    }
}
