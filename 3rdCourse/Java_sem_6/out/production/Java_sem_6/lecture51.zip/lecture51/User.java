package lecture51;

public class User {
    private String name ="Vasiliy";
    private String surname = "Perevalov";

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }
}
