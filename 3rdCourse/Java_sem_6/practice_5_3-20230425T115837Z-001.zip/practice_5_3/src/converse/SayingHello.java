package converse;

import greetings.MyName;

public class SayingHello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyName say = new MyName();
		say.sayHello();
		say.setName("Bob");
		say.sayHello();
	}

}
